library(roxygen2)
library(devtools)
setwd("..")

roxygen2::roxygenize()
devtools::build()
devtools::check()
devtools::install(
  upgrade = FALSE,
  quick   = TRUE
)

devtools::load_all()

library(clValid2)
